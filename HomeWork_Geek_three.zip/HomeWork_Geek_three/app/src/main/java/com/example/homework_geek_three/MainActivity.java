package com.example.homework_geek_three;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.ItemTouchHelper;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Toast;
//
//import com.example.homework_geek_three.recyclerAdapter.Adapter;
//
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.List;
//
//public class MainActivity extends AppCompatActivity implements View.OnClickListener, Adapter.ItemClickListener {
//    RecyclerView firstRecyclerView;
//    Adapter firstMainAdapter;
//    List<String> list;
//    Button button;
//    EditText editText;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        init();
//    }
//
//    private void init() {
//        button = findViewById(R.id.btnSend);
//        editText = findViewById(R.id.info);
//
//        button.setOnClickListener(this);
//        list = new ArrayList<>();
//
//        firstRecyclerView = findViewById(R.id.recycler);
//        firstRecyclerView.setLayoutManager(new LinearLayoutManager(this));
//        firstMainAdapter = new Adapter(list, this);
//        firstRecyclerView.setAdapter(firstMainAdapter);
//        firstMainAdapter.setOnClickListener(this);
//
//        new ItemTouchHelper(simpleCallback).attachToRecyclerView(firstRecyclerView);
//    }
//
//    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, ItemTouchHelper.RIGHT) {
//        @Override
//        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder,
//                              @NonNull RecyclerView.ViewHolder target) {
//            int position = viewHolder.getAdapterPosition();
//            int positionTarget = target.getAdapterPosition();
//            Collections.swap(firstMainAdapter.list, position, positionTarget);
//            firstMainAdapter.notifyItemMoved(position, positionTarget);
//            return true;
//        }
//
//        @Override
//        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
//            firstMainAdapter.list.remove(viewHolder.getAdapterPosition());
//            firstMainAdapter.notifyItemRemoved(viewHolder.getAdapterPosition());
//        }
//    };
//
//    @Override
//    public void onClick(View v) {
//
//    }
//
//
//    @Override
//    public void inItemClick(int position) {
//        Toast.makeText(getApplicationContext(), "" + position, Toast.LENGTH_SHORT).show();
//    }
//}

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.homework_geek_three.recyclerAdapter.ExampleAdapter;
import com.example.homework_geek_three.recyclerAdapter.ExampleItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<ExampleItem> mExampleList;

    RecyclerView mRecyclerView;
    ExampleAdapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;

    Button buttonInsert;
    Button buttonRemove;
    private EditText editTextInsert;
    private EditText editTextRemove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createExampleList();
        buildRecyclerView();
        setButtons();
    }

    public void insertItem(int position) {
        mExampleList.add(position, new ExampleItem(R.drawable.ic_android, "New Item At Position" + position, "This is Line 2"));
        mAdapter.notifyItemInserted(position);
    }

    public void removeItem(int position) {
        mExampleList.remove(position);
        mAdapter.notifyItemRemoved(position);
    }

    public void changeItem(int position, String text) {
        mExampleList.get(position).changeText1(text);
        mAdapter.notifyItemChanged(position);
    }

    public void createExampleList() {
        mExampleList = new ArrayList<>();
        mExampleList.add(new ExampleItem(R.drawable.ic_android, "Line 1", "Line 2"));
        mExampleList.add(new ExampleItem(R.drawable.ic_audio, "Line 3", "Line 4"));
        mExampleList.add(new ExampleItem(R.drawable.ic_sun, "Line 5", "Line 6"));
    }

    public void buildRecyclerView() {
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(mExampleList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                changeItem(position, "Clicked");
            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }
        });
    }

    public void setButtons() {
        buttonInsert = findViewById(R.id.button_insert);
        buttonRemove = findViewById(R.id.button_remove);
        editTextInsert = findViewById(R.id.edittext_insert);
        editTextRemove = findViewById(R.id.edittext_remove);

        buttonInsert.setOnClickListener(v -> {
            int position = Integer.parseInt(editTextInsert.getText().toString());
            insertItem(position);
        });

        buttonRemove.setOnClickListener(v -> {
            int position = Integer.parseInt(editTextRemove.getText().toString());
            removeItem(position);
        });
    }
}