package com.rajendra.foodapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rajendra.foodapp.adapter.AsiaFoodAdapter;
import com.rajendra.foodapp.adapter.PopularFoodAdapter;
import com.rajendra.foodapp.map.Map;
import com.rajendra.foodapp.model.AsiaFood;
import com.rajendra.foodapp.model.PopularFood;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RecyclerView popularRecycler, asiaRecycler;
    PopularFoodAdapter popularFoodAdapter;
    AsiaFoodAdapter asiaFoodAdapter;
    ImageView calling_admin, searching, admin_logo;
    EditText to_search;
    BottomAppBar menu;
    Intent new_page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        menu = findViewById(R.id.bottomAppBar2);
        //nanoid
        menu.setOnClickListener(this);

        admin_logo = findViewById(R.id.imageView);
        admin_logo.setOnClickListener(this);

        to_search = findViewById(R.id.editText);
        calling_admin = findViewById(R.id.imageView2);
        calling_admin.setOnClickListener(this);

        searching = findViewById(R.id.imageView3);
        searching.setOnClickListener(this);

        List<PopularFood> popularFoodList = new ArrayList<>();

        popularFoodList.add(new PopularFood("Float Cake Vietnam", "175 com", R.drawable.popularfood1));
        popularFoodList.add(new PopularFood("Chiken Drumstick", "255 com", R.drawable.popularfood2));
        popularFoodList.add(new PopularFood("Fish Tikka Stick", "225 com", R.drawable.popularfood3));
        popularFoodList.add(new PopularFood("Float Cake Vietnam", "300 com", R.drawable.popularfood1));
        popularFoodList.add(new PopularFood("Chiken Drumstick", "200 com", R.drawable.popularfood2));
        popularFoodList.add(new PopularFood("Fish Tikka Stick", "340 com", R.drawable.popularfood3));

        setPopularRecycler(popularFoodList);

        List<AsiaFood> asiaFoodList = new ArrayList<>();
        asiaFoodList.add(new AsiaFood("Chicago Pizza", "200 com", R.drawable.asiafood1, "4.5", "Briand Restaurant"));
        asiaFoodList.add(new AsiaFood("Straberry Cake", "250 com", R.drawable.asiafood2, "4.2", "Friends Restaurant"));
        asiaFoodList.add(new AsiaFood("Chicago Pizza", "200 com", R.drawable.asiafood1, "4.5", "Briand Restaurant"));
        asiaFoodList.add(new AsiaFood("Straberry Cake", "250 com", R.drawable.asiafood2, "4.2", "Friends Restaurant"));
        asiaFoodList.add(new AsiaFood("Chicago Pizza", "200 com", R.drawable.asiafood1, "4.5", "Briand Restaurant"));
        asiaFoodList.add(new AsiaFood("Straberry Cake", "250 com", R.drawable.asiafood2, "4.2", "Friends Restaurant"));

        setAsiaRecycler(asiaFoodList);

        FloatingActionButton fab = findViewById(R.id.floatingActionButton2);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new_page = new Intent(MainActivity.this, Map.class);
                startActivity(new_page);
            }
        });

    }


    private void setPopularRecycler(List<PopularFood> popularFoodList) {

        popularRecycler = findViewById(R.id.popular_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        popularRecycler.setLayoutManager(layoutManager);
        popularFoodAdapter = new PopularFoodAdapter(this, popularFoodList);
        popularRecycler.setAdapter(popularFoodAdapter);

    }

    private void setAsiaRecycler(List<AsiaFood> asiaFoodList) {

        asiaRecycler = findViewById(R.id.asia_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        asiaRecycler.setLayoutManager(layoutManager);
        asiaFoodAdapter = new AsiaFoodAdapter(this, asiaFoodList);
        asiaRecycler.setAdapter(asiaFoodAdapter);

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imageView2:
                Toast.makeText(getApplicationContext(), "Will created soon", Toast.LENGTH_SHORT).show();
                break;
            case R.id.imageView3:
                searching_menu();
                break;
            case R.id.bottomAppBar2:
                Toast.makeText(getApplicationContext(), "Don't forget We love you!", Toast.LENGTH_LONG).show();
                break;
            case R.id.imageView:
                Intent intent = new Intent(MainActivity.this, Admin_page.class);
                startActivity(intent);
                break;
            default:
                Toast.makeText(getApplicationContext(), "You have wrong thing", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void searching_menu() {
        String st_search = to_search.getText().toString();
        Toast.makeText(getApplicationContext(), st_search, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.bottom_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.account:
                Intent intent = new Intent(MainActivity.this, Admin_page.class);
                startActivity(intent);
                break;
            case R.id.heart:
                Toast.makeText(getApplicationContext(), "Not ready yet((", Toast.LENGTH_SHORT).show();
                break;
            default:
                Toast.makeText(getApplicationContext(), "You have a wrong ((", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    //https://bishkek.adresa-telefony.ru/aldo_coffee_kofejnja-70000001039881302.html
}
