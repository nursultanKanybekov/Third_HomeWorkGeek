package com.rajendra.foodapp.buypart;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.rajendra.foodapp.R;

import java.util.Objects;

public class Banks_Type extends AppCompatDialogFragment {
    Button this_app;
    NumberPicker numberPicker;
    int chosen_banks;
    Intent pay_activity;
    String bank = "";

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = Objects.requireNonNull(getActivity()).getLayoutInflater();
        View view = inflater.inflate(R.layout.activity_banks__type, null);

        numberPicker = view.findViewById(R.id.np);
        numberPicker.setMaxValue(5);
        String[] strs = {"Elsom", "Ayil bank", "Optima bank", "Bakay bank", "RSK bank", "Demir bank"};
        numberPicker.setDisplayedValues(strs);
        numberPicker.setWrapSelectorWheel(true);

        chosen_banks = numberPicker.getValue();
        switch (chosen_banks) {
            case 0:
                bank = "Elsom";
                break;
            case 1:
                bank = "Ayil bank";
                break;
            case 2:
                bank = "Optima bank";
                break;
            case 3:
                bank = "Bakay bank";
                break;
            case 4:
                bank = "RSK bank";
                break;
            case 5:
                bank = "Demir bank";
                break;
            default:
                bank = "error";
                break;
        }

        builder.setView(view)
                .setTitle("Choose the online banking please")
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                })
                .setPositiveButton("continue", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        pay_activity = new Intent(getActivity(), Web_Page.class);
                        pay_activity.putExtra("KEY_1",bank);
                        startActivity(pay_activity);
                    }
                });
        this_app = view.findViewById(R.id.to_app);
        this_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pay_activity = new Intent(getActivity(), Buy_Activity.class);
                startActivity(pay_activity);
            }
        });

        final AlertDialog alert = builder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onShow(DialogInterface dialog) {
                alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.black);
                alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.black);
            }
        });
        return alert;
    }
}