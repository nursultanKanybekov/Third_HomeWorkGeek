package com.rajendra.foodapp.for_check;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.rajendra.foodapp.Next_Part;
import com.rajendra.foodapp.R;


public class Upload_Check extends AppCompatActivity implements View.OnClickListener {
    ImageView upload_image, back;
    Button upload, send;
    private static final int IMAGE_PICK_CODE = 1000;
    private static final int PERMISSION_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload__check);

        back = findViewById(R.id.back_5);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        upload_image = findViewById(R.id.upload_image);
        upload_image.setOnClickListener(this);
        upload = findViewById(R.id.upload_btn);
        upload.setOnClickListener(this);
        send = findViewById(R.id.upload_check);
        send.setOnClickListener(this);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.upload_image:
            case R.id.upload_btn:
                upload_f();
                break;
            case R.id.upload_check:
                Intent intent = new Intent(Upload_Check.this, Next_Part.class);
                startActivity(intent);
                break;
        }
    }

    private void upload_f() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE};
                requestPermissions(permission, PERMISSION_CODE);
            } else {
                pickImageFromGallary();
            }
        } else {
            pickImageFromGallary();
        }
    }

    private void pickImageFromGallary() {
        Intent image_i = new Intent(Intent.ACTION_PICK);
        image_i.setType("image/*");
        startActivityForResult(image_i, IMAGE_PICK_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    pickImageFromGallary();
                } else {
                    Toast.makeText(getApplicationContext(), "Permission danied", Toast.LENGTH_SHORT).show();
                }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_OK && requestCode == IMAGE_PICK_CODE) {
            upload_image.setImageURI(data.getData());
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}