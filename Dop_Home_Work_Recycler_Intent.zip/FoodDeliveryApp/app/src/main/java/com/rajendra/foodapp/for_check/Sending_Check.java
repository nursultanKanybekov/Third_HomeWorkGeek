package com.rajendra.foodapp.for_check;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.rajendra.foodapp.Next_Part;
import com.rajendra.foodapp.R;

public class Sending_Check extends AppCompatActivity {

    private static final int pic_id = 123;
    Button camera_open_id, send;
    ImageView click_image_id, back;
    boolean is_took = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sending__check);

        back = findViewById(R.id.back_4);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        camera_open_id = findViewById(R.id.camera_button);
        click_image_id = findViewById(R.id.click_image);

        camera_open_id.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent camera_intent
                        = new Intent(MediaStore
                        .ACTION_IMAGE_CAPTURE);
                startActivityForResult(camera_intent, pic_id);
            }
        });
        send = findViewById(R.id.send);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (is_took) {
                    Intent main = new Intent(Sending_Check.this, Next_Part.class);
                    startActivity(main);
                } else {
                    Toast.makeText(getApplicationContext(), "Firstly take a photo", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == pic_id) {
            Bitmap photo = (Bitmap) data.getExtras()
                    .get("data");
            click_image_id.setImageBitmap(photo);
            is_took = true;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}