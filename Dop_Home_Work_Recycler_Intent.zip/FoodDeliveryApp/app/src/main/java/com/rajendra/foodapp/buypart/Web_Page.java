package com.rajendra.foodapp.buypart;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.rajendra.foodapp.R;
import com.rajendra.foodapp.for_check.Sending_Check;
import com.rajendra.foodapp.for_check.Upload_Check;


public class Web_Page extends AppCompatActivity implements View.OnClickListener {
    WebView webView;
    String taken_bank = "";
    ImageView back;
    Button upload, take_photo;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web__page);

        upload = findViewById(R.id.upload_check);
        upload.setOnClickListener(this);

        take_photo = findViewById(R.id.take_check);
        take_photo.setOnClickListener(this);

        back = findViewById(R.id.back_6);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        Bundle extras = getIntent().getExtras();
        taken_bank = extras.getString("KEY_1");

        switch (taken_bank) {
            case "Elsom":
                online_bank("https://web.elsom.kg/ru/login/msisdn");
                break;
            case "Ayil bank":
                online_bank("https://www.ab.kg/bankovskie-uslugi-uridicheskim-licam/internet-banking");
                break;
            case "Optima bank":
                online_bank("https://online.optimabank.kg/ib6/iclient/index.html");
                break;
            case "Bakay bank":
                online_bank("https://bakai.kg/ru/news/onlajn-banking-bakaj-bank/");
                break;
            case "RSK bank":
                online_bank("https://www.rsk.kg/en/yur_banking");
                break;
            case "Demir bank":
                online_bank("https://online.demirbank.kg/retail/login?lang=en");
                break;
            default:
                Toast.makeText(getApplicationContext(), "Sorry i can't found this bank", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent page;
        switch (item.getItemId()) {
            case R.id.upload:
                page = new Intent(Web_Page.this, Upload_Check.class);
                startActivity(page);
                break;
            case R.id.send_check:
                page = new Intent(Web_Page.this, Sending_Check.class);
                startActivity(page);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void online_bank(String link) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        startActivity(browserIntent);
    }

    @SuppressLint("SetJavaScriptEnabled")
    /*private void online_bank(String link) {
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setInitialScale(1);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDomStorageEnabled(true);

        final Activity activity = this;

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }

            @TargetApi(android.os.Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError rerr) {
                onReceivedError(view, rerr.getErrorCode(), rerr.getDescription().toString(), req.getUrl().toString());
            }
        });
        webView.loadUrl(link);
        setContentView(webView);
    }*/

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        Intent page;
        switch (v.getId()) {
            case R.id.take_check:
                page = new Intent(Web_Page.this, Sending_Check.class);
                startActivity(page);
                break;
            case R.id.upload_check:
                page = new Intent(Web_Page.this, Upload_Check.class);
                startActivity(page);
                break;
        }
    }
}