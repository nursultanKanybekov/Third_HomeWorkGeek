package com.rajendra.foodapp.map;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.rajendra.foodapp.R;

public class Map extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        String map = "https://www.google.com/maps/place/Aldo+Coffee/@42.8571381,74.610084,17z/data=!4m12!1m6!3m5!1s0x389eb7cd539501a9:0x1736b7f030f98f17!2sAldo+Coffee!8m2!3d42.8571381!4d74.6122727!3m4!1s0x389eb7cd539501a9:0x1736b7f030f98f17!8m2!3d42.8571381!4d74.6122727";
        for_map(map);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void for_map(String map) {
        WebView webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);

        final Activity activity = this;

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }

            @TargetApi(android.os.Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError rerr) {
                onReceivedError(view, rerr.getErrorCode(), rerr.getDescription().toString(), req.getUrl().toString());
            }
        });
        webView.loadUrl(map);
        setContentView(webView);
    }
}