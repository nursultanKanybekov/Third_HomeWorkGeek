package com.rajendra.foodapp;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.rajendra.foodapp.buypart.Banks_Type;
import com.rajendra.foodapp.buypart.Buy_Activity;

import java.util.ArrayList;


public class Next_Part extends AppCompatActivity {
    Button to_buy;
    AlertDialog.Builder builder;
    Intent pay_activity;
    ImageView back, cancel_first, cancel_second, cancel_third, cancel_fourth, cancel_fife, cancel_sixth, cancel_seventh;
    CheckBox one, two, three, four, fife, six, seven;
    EditText brone_time;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_part);

        brone_time = findViewById(R.id.editText);
        one = findViewById(R.id.firstCh);
        two = findViewById(R.id.secondCh);
        three = findViewById(R.id.thirdCh);
        four = findViewById(R.id.fourthCh);
        fife = findViewById(R.id.fifethCh);
        six = findViewById(R.id.sixthCh);
        seven = findViewById(R.id.seventhCh);

        cancel_first = findViewById(R.id.imageView14);
        cancel_second = findViewById(R.id.imageView13);
        cancel_third = findViewById(R.id.imageView15);
        cancel_fourth = findViewById(R.id.imageView16);
        cancel_fife = findViewById(R.id.imageView17);
        cancel_sixth = findViewById(R.id.imageView18);
        cancel_seventh = findViewById(R.id.imageView19);

        back = findViewById(R.id.back_3);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        to_buy = findViewById(R.id.buy);
        builder = new AlertDialog.Builder(this);
        to_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checked_place()) {
                    String checker = brone_time.getText().toString();
                    if (!checker.equals("")) {
                        builder.setMessage("Well come").setTitle("By web application or by this app");

                        builder.setMessage("By web application or by this app ?")
                                .setCancelable(false)
                                .setPositiveButton("app", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();

                                        pay_activity = new Intent(Next_Part.this, Buy_Activity.class);
                                        startActivity(pay_activity);
                                    }
                                })
                                .setNegativeButton("web", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                        typeOfOnlineBanks();
                                    }
                                });

                        final AlertDialog alert = builder.create();
                        alert.setOnShowListener(new DialogInterface.OnShowListener() {
                            @Override
                            public void onShow(DialogInterface dialog) {
                                alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.black);
                                alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.black);
                            }
                        });
                        alert.setTitle("Choose to pay!");
                        alert.show();
                    } else {
                        Toast.makeText(getApplicationContext(), "You are forget about time to brone", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please choose the place", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean checked_place() {
        boolean checker = false;
        StringBuilder result = new StringBuilder();
        ArrayList<String> brone = new ArrayList<>();
        result.append("Broned places by you:");

        if (one.isChecked()) {
            result.append("\nFirst places");
            brone.add("first");
            cancel_first.setVisibility(View.VISIBLE);
            checker = true;
        } else {
            cancel_first.setVisibility(View.INVISIBLE);
        }
        if (two.isChecked()) {
            result.append("\nSecond places");
            brone.add("second");
            cancel_second.setVisibility(View.VISIBLE);
            checker = true;
        } else {
            cancel_second.setVisibility(View.INVISIBLE);
        }
        if (three.isChecked()) {
            result.append("\nThird places");
            brone.add("third");
            cancel_third.setVisibility(View.VISIBLE);
            checker = true;
        } else {
            cancel_third.setVisibility(View.INVISIBLE);
        }
        if (four.isChecked()) {
            result.append("\nFourth places");
            brone.add("first");
            cancel_fourth.setVisibility(View.VISIBLE);
            checker = true;
        } else {
            cancel_fourth.setVisibility(View.INVISIBLE);
        }
        if (fife.isChecked()) {
            result.append("\nFifeth places");
            brone.add("fife");
            cancel_fife.setVisibility(View.VISIBLE);
            checker = true;
        } else {
            cancel_fife.setVisibility(View.INVISIBLE);
        }
        if (six.isChecked()) {
            result.append("\nSixth places");
            brone.add("six");
            cancel_sixth.setVisibility(View.VISIBLE);
            checker = true;
        } else {
            cancel_sixth.setVisibility(View.INVISIBLE);
        }
        if (seven.isChecked()) {
            result.append("\nSeventh places");
            brone.add("seven");
            cancel_seventh.setVisibility(View.VISIBLE);
            checker = true;
        } else {
            cancel_seventh.setVisibility(View.INVISIBLE);
        }
        //Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();
        return checker;
    }

    private void typeOfOnlineBanks() {
        Banks_Type banks_type = new Banks_Type();
        banks_type.show(getSupportFragmentManager(), "Choose the bank please");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}