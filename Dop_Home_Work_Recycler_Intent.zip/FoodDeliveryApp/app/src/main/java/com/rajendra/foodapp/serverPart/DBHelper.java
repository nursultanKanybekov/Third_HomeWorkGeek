package com.rajendra.foodapp.serverPart;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public static final int DATA_V = 1;
    public static final String DATA_NAME = "contactDb";
    public static final String DATA_CONTACTS = "contacts";

    public static final String KEY_ID = "_id";
    public static final String KEY_PLACE = "place";

    public DBHelper(@Nullable Context context) {
        super(context, DATA_NAME, null, DATA_V);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DATA_CONTACTS + "(" + KEY_ID + " integer primary key," + KEY_PLACE + " text" + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + DATA_CONTACTS);
        onCreate(db);
    }
}
