package com.rajendra.foodapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.rajendra.foodapp.buypart.Buy_Activity;

public class DetailsActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView paying, clicking_back, for_share, save_food, increment_button, decrement_button, image_food;
    TextView saved, much_of_food, price, name_food;
    boolean check_saved = true;

    String name, pricest, imageUrl;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Intent intent = getIntent();

        name = intent.getStringExtra("name");
        pricest = intent.getStringExtra("price");
        imageUrl = intent.getStringExtra("image");

        saved = findViewById(R.id.textView5);
        much_of_food = findViewById(R.id.textView13);
        price = findViewById(R.id.textView14);
        name_food = findViewById(R.id.textView11);
        image_food = findViewById(R.id.imageView8);

        paying = findViewById(R.id.imageView12);
        paying.setOnClickListener(this);

        clicking_back = findViewById(R.id.imageView5);
        clicking_back.setOnClickListener(this);

        for_share = findViewById(R.id.imageView6);
        for_share.setOnClickListener(this);

        save_food = findViewById(R.id.imageView7);
        save_food.setOnClickListener(this);

        increment_button = findViewById(R.id.imageView10);
        increment_button.setOnClickListener(this);

        decrement_button = findViewById(R.id.imageView11);
        decrement_button.setOnClickListener(this);

        Glide.with(getApplicationContext()).load(imageUrl).into(image_food);
        name_food.setText(name);
        price.setText(pricest);
        switch (name) {
            case "Float Cake Vietnam":
                image_food.setImageResource(R.drawable.popularfood1);
                break;
            case "Chiken Drumstick":
                image_food.setImageResource(R.drawable.popularfood2);
                break;
            case "Fish Tikka Stick":
                image_food.setImageResource(R.drawable.popularfood3);
                break;
            case "Chicago Pizza":
                image_food.setImageResource(R.drawable.asiafood1);
                break;
            case "Straberry Cake":
                image_food.setImageResource(R.drawable.asiafood2);
                break;
        }
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imageView12:
                pay_or_stay();
                break;
            case R.id.imageView5:
                onBackPressed();
                break;
            case R.id.imageView6:
                shareButton();
                break;
            case R.id.imageView7:
                saved_button();
                break;
            case R.id.imageView10:
                increment();
                break;
            case R.id.imageView11:
                decrement();
                break;
        }

    }

    private void pay_or_stay() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Well come").setTitle("By web application or by this app");

        builder.setMessage("Continue to buy or brone a place")
                .setCancelable(false)
                .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                        Intent intent = new Intent(DetailsActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("Brone", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        Intent intent = new Intent(DetailsActivity.this, Next_Part.class);
                        startActivity(intent);
                    }
                });

        final AlertDialog alert = builder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onShow(DialogInterface dialog) {
                alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(R.color.black);
                alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(R.color.black);
            }
        });
        alert.setTitle("Choose to pay!");
        alert.show();
    }

    @SuppressLint("SetTextI18n")
    private void decrement() {
        int save_st = Integer.parseInt(much_of_food.getText().toString());
        String i_price = price.getText().toString();
        save_st++;
        int price_temp = Integer.parseInt(stripNonDigits(i_price)) * 2;
        String new_price = String.valueOf(price_temp);
        String new_saved = String.valueOf(save_st);
        much_of_food.setText(new_saved);
        price.setText(new_price + " com");
    }

    @SuppressLint("SetTextI18n")
    private void increment() {
        int save_st = Integer.parseInt(much_of_food.getText().toString());
        String i_price = price.getText().toString();
        if (save_st > 1) {
            save_st--;
            int price_temp = Integer.parseInt(stripNonDigits(i_price)) / 2;
            String new_price = String.valueOf(price_temp);
            String new_saved = String.valueOf(save_st);
            much_of_food.setText(new_saved);
            price.setText(new_price + " com");
        }
    }

    public static String stripNonDigits(final CharSequence input) {
        final StringBuilder sb = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            final char c = input.charAt(i);
            if (c > 47 && c < 58) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private void saved_button() {
        if (check_saved) {
            int save_st = Integer.parseInt(saved.getText().toString());
            save_st++;
            String new_saved = String.valueOf(save_st);
            saved.setText(new_saved);
            check_saved = false;
        } else {
            Toast.makeText(getApplicationContext(), "You are saved it))", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareButton() {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        String body = "Float Cake Vietnam";
        String sub = "Your Subject";
        share.putExtra(Intent.EXTRA_SUBJECT, sub);
        share.putExtra(Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(share, "Share Using"));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
